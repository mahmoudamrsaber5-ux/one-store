require('dotenv').config();
const express = require('express');
const cookieParser = require('cookie-parser');
const jwt = require('jsonwebtoken');
const path = require('path');

const app = express();
app.use(express.json({limit:'1mb'}));
app.use(cookieParser());
app.use(express.static(path.join(__dirname, 'public')));

const PORT = process.env.PORT || 3000;
const SHOP = process.env.SHOPIFY_SHOP;
const CLIENT_ID = process.env.SHOPIFY_CLIENT_ID;
const CLIENT_SECRET = process.env.SHOPIFY_CLIENT_SECRET;
const API_VERSION = process.env.SHOPIFY_API_VERSION || '2026-07';
const ADMIN_EMAIL = process.env.ADMIN_EMAIL;
const ADMIN_PASSWORD = process.env.ADMIN_PASSWORD;
const SESSION_SECRET = process.env.SESSION_SECRET;

if (!SHOP || !CLIENT_ID || !CLIENT_SECRET || !ADMIN_EMAIL || !ADMIN_PASSWORD || !SESSION_SECRET) {
  console.warn('Missing environment variables. Copy .env.example to .env and fill it before using the dashboard.');
}

let tokenCache = { token: null, expiresAt: 0 };

function authRequired(req, res, next) {
  try {
    const token = req.cookies.pandax_session;
    if (!token) return res.status(401).json({error:'UNAUTHORIZED'});
    const payload = jwt.verify(token, SESSION_SECRET);
    if (payload.email !== ADMIN_EMAIL) throw new Error('bad session');
    req.admin = payload;
    next();
  } catch (e) {
    res.status(401).json({error:'UNAUTHORIZED'});
  }
}

async function getShopifyToken() {
  if (tokenCache.token && Date.now() < tokenCache.expiresAt - 60_000) return tokenCache.token;
  const url = `https://${SHOP}/admin/oauth/access_token`;
  const r = await fetch(url, {
    method:'POST',
    headers:{'Content-Type':'application/x-www-form-urlencoded'},
    body:new URLSearchParams({grant_type:'client_credentials', client_id:CLIENT_ID, client_secret:CLIENT_SECRET})
  });
  const data = await r.json();
  if (!r.ok || !data.access_token) throw new Error(`Shopify token error: ${JSON.stringify(data)}`);
  tokenCache = { token:data.access_token, expiresAt:Date.now() + ((data.expires_in || 86399) * 1000) };
  return tokenCache.token;
}

async function shopifyGraphQL(query, variables={}) {
  const token = await getShopifyToken();
  const r = await fetch(`https://${SHOP}/admin/api/${API_VERSION}/graphql.json`, {
    method:'POST',
    headers:{'Content-Type':'application/json','X-Shopify-Access-Token':token},
    body:JSON.stringify({query, variables})
  });
  const json = await r.json();
  if (!r.ok || json.errors) throw new Error(JSON.stringify(json.errors || json));
  return json.data;
}

app.get('/api/session', (req,res)=>{
  try {
    const p = jwt.verify(req.cookies.pandax_session, SESSION_SECRET);
    return res.json({authenticated:true,email:p.email});
  } catch { return res.json({authenticated:false}); }
});

app.post('/api/login',(req,res)=>{
  const {email,password} = req.body || {};
  if (email !== ADMIN_EMAIL || password !== ADMIN_PASSWORD) return res.status(401).json({error:'بيانات الدخول غير صحيحة'});
  const token = jwt.sign({email,role:'owner'}, SESSION_SECRET, {expiresIn:'8h'});
  res.cookie('pandax_session', token, {httpOnly:true,secure:process.env.NODE_ENV==='production',sameSite:'lax',maxAge:8*60*60*1000});
  res.json({ok:true});
});
app.post('/api/logout',(req,res)=>{res.clearCookie('pandax_session');res.json({ok:true});});

const PRODUCT_QUERY = `query Products($first:Int!,$after:String){
  products(first:$first,after:$after,sortKey:UPDATED_AT,reverse:true){
    pageInfo{hasNextPage endCursor}
    nodes{
      id title handle status totalInventory
      featuredMedia{preview{image{url altText}}}
      variants(first:20){nodes{id title price compareAtPrice sku inventoryQuantity availableForSale}}
      metafields(first:20){nodes{namespace key type value}}
    }
  }
}`;

app.get('/api/products',authRequired,async(req,res)=>{
  try {
    const data=await shopifyGraphQL(PRODUCT_QUERY,{first:50,after:req.query.after||null});
    res.json(data.products);
  } catch(e){res.status(500).json({error:e.message});}
});

app.get('/api/products/:id',authRequired,async(req,res)=>{
  try {
    const q=`query Product($id:ID!){product(id:$id){id title handle descriptionHtml status vendor productType totalInventory featuredMedia{preview{image{url altText}}} variants(first:100){nodes{id title price compareAtPrice sku inventoryQuantity availableForSale selectedOptions{name value}}} metafields(first:50){nodes{namespace key type value}}}}`;
    const data=await shopifyGraphQL(q,{id:req.params.id});
    res.json(data.product);
  } catch(e){res.status(500).json({error:e.message});}
});

app.post('/api/products/:id',authRequired,async(req,res)=>{
  try {
    const p=req.body||{};
    const productFields={id:req.params.id};
    if (typeof p.title==='string') productFields.title=p.title;
    if (typeof p.status==='string') productFields.status=p.status;
    if (typeof p.descriptionHtml==='string') productFields.descriptionHtml=p.descriptionHtml;
    if (typeof p.vendor==='string') productFields.vendor=p.vendor;
    if (typeof p.productType==='string') productFields.productType=p.productType;
    const result=await shopifyGraphQL(`mutation UpdateProduct($product:ProductUpdateInput!){productUpdate(product:$product){product{id title status} userErrors{field message}}}`,{product:productFields});
    const errors=result.productUpdate.userErrors||[];
    if(errors.length) return res.status(400).json({error:errors.map(x=>x.message).join(' | ')});
    if(Array.isArray(p.variants) && p.variants.length){
      const variants=p.variants.map(v=>({id:v.id,price:String(v.price),compareAtPrice:v.compareAtPrice===null||v.compareAtPrice===''?null:String(v.compareAtPrice)}));
      const vr=await shopifyGraphQL(`mutation UpdateVariants($productId:ID!,$variants:[ProductVariantsBulkInput!]!){productVariantsBulkUpdate(productId:$productId,variants:$variants){product{id} userErrors{field message}}}`,{productId:req.params.id,variants});
      const ve=vr.productVariantsBulkUpdate.userErrors||[];
      if(ve.length) return res.status(400).json({error:ve.map(x=>x.message).join(' | ')});
    }
    if(p.meta && typeof p.meta==='object'){
      const defs={
        rating:{type:'number_decimal',key:'rating'},
        rating_count:{type:'number_integer',key:'rating_count'},
        badge:{type:'single_line_text_field',key:'badge'},
        payment_modes:{type:'json',key:'payment_modes'},
        offer_end:{type:'date_time',key:'offer_end'}
      };
      const metafields=[];
      for(const [name,def] of Object.entries(defs)){
        if(!(name in p.meta)) continue;
        let value=p.meta[name];
        if(value===null || value==='') continue;
        if(name==='payment_modes') value=JSON.stringify(value);
        metafields.push({ownerId:req.params.id,namespace:'pandax',key:def.key,type:def.type,value:String(value)});
      }
      if(metafields.length){
        const mr=await shopifyGraphQL(`mutation SetMetafields($metafields:[MetafieldsSetInput!]!){metafieldsSet(metafields:$metafields){metafields{namespace key value} userErrors{field message}}}`,{metafields});
        const me=mr.metafieldsSet.userErrors||[];
        if(me.length) return res.status(400).json({error:me.map(x=>x.message).join(' | ')});
      }
    }
    res.json({ok:true});
  } catch(e){res.status(500).json({error:e.message});}
});

app.get('/api/orders',authRequired,async(req,res)=>{
  try {
    const q=`query Orders($first:Int!,$after:String){orders(first:$first,after:$after,sortKey:CREATED_AT,reverse:true){pageInfo{hasNextPage endCursor}nodes{id name createdAt displayFinancialStatus displayFulfillmentStatus totalPriceSet{shopMoney{amount currencyCode}} lineItems(first:50){nodes{title quantity variant{sku}}}}}}`;
    const data=await shopifyGraphQL(q,{first:50,after:req.query.after||null});
    res.json(data.orders);
  } catch(e){res.status(500).json({error:e.message});}
});

app.get('/api/dashboard',authRequired,async(req,res)=>{
  try {
    const q=`query Dash{products(first:1){totalCount} orders(first:50,sortKey:CREATED_AT,reverse:true){nodes{createdAt totalPriceSet{shopMoney{amount currencyCode}}}} shop{name currencyCode}}`;
    const data=await shopifyGraphQL(q);
    const orders=data.orders.nodes||[];
    const today=new Date().toISOString().slice(0,10);
    const todayOrders=orders.filter(o=>o.createdAt.slice(0,10)===today);
    const sales=orders.reduce((s,o)=>s+Number(o.totalPriceSet?.shopMoney?.amount||0),0);
    res.json({shop:data.shop,productCount:data.products.totalCount||0,ordersCount:orders.length,todayOrders:todayOrders.length,recentSales:sales});
  } catch(e){res.status(500).json({error:e.message});}
});

app.post('/api/setup-metafields',authRequired,async(req,res)=>{
  try{
    const defs=[
      ['تقييم المنتج','rating','number_decimal','تقييم PandaX من 0 إلى 5'],
      ['عدد التقييمات','rating_count','number_integer','عدد التقييمات الظاهرة'],
      ['شارة المنتج','badge','single_line_text_field','مثل الأكثر مبيعًا أو عرض محدود أو جديد'],
      ['طرق الدفع','payment_modes','json','قائمة طرق الدفع المتاحة لهذا المنتج'],
      ['نهاية العرض','offer_end','date_time','تاريخ ووقت نهاية العرض']
    ];
    const results=[];
    for(const [name,key,type,description] of defs){
      const r=await shopifyGraphQL(`mutation Def($definition:MetafieldDefinitionInput!){metafieldDefinitionCreate(definition:$definition){createdDefinition{id name namespace key type} userErrors{field message}}}`,{definition:{name,namespace:'pandax',key,type,description,ownerType:'PRODUCT'}});
      results.push({key,created:r.metafieldDefinitionCreate.createdDefinition,errors:r.metafieldDefinitionCreate.userErrors});
    }
    res.json({results});
  }catch(e){res.status(500).json({error:e.message});}
});

app.use((req,res)=>res.sendFile(path.join(__dirname,'public','index.html')));
app.listen(PORT,()=>console.log(`PandaX Admin running on http://localhost:${PORT}`));

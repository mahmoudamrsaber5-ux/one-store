# PandaX Admin — لوحة إدارة مستقلة لمتجر Shopify

هذه النسخة هي لوحة مستقلة عن قالب المتجر. تعمل كخادم Node/Express وتستخدم Shopify Admin GraphQL API.

## ما الذي تتحكم به الآن؟
- تسجيل دخول للمدير.
- لوحة إحصائيات.
- قراءة المنتجات من Shopify.
- تعديل اسم المنتج وحالته.
- تعديل السعر الحالي والسعر قبل الخصم للـ variant الأول.
- تقييم المنتج وعدد التقييمات.
- شارة المنتج.
- طرق الدفع الخاصة بالمنتج.
- تاريخ نهاية العرض.
- قراءة آخر الطلبات.
- تجهيز Metafields الخاصة بـ PandaX تلقائيًا.

## الحقول التي تستخدمها اللوحة
namespace: `pandax`
- `rating` — number_decimal
- `rating_count` — number_integer
- `badge` — single_line_text_field
- `payment_modes` — json
- `offer_end` — date_time

## قبل التشغيل
1. ثبّت Node.js 20 أو أحدث.
2. افتح Dev Dashboard في Shopify وأنشئ تطبيقًا جديدًا.
3. في نسخة التطبيق اطلب الصلاحيات:
   - read_products
   - write_products
   - read_orders
4. ثبّت التطبيق على متجرك.
5. من Settings > Credentials خذ Client ID وClient Secret.
6. انسخ `.env.example` إلى `.env` واملأ القيم.
7. نفّذ `npm install` ثم `npm start`.
8. افتح `http://localhost:3000`.
9. سجّل دخول المدير بالقيم الموجودة في `.env`.
10. افتح الرئيسية واضغط `تجهيز حقول PandaX لأول مرة`.

## مهم عن طريقة المصادقة
اللوحة تستخدم Client Credentials Grant، وهو مناسب عندما يكون التطبيق والمتجر داخل نفس Shopify organization. التوكن الناتج صالح 24 ساعة تقريبًا ويعيد السيرفر طلب توكن جديد تلقائيًا عند الحاجة.

إذا كان المتجر خارج نفس organization أو أردت توزيع التطبيق على متاجر أخرى، يجب تحويل المشروع إلى OAuth/Shopify CLI flow بدل هذا المسار.

## ربط القالب
القالب الحالي لديه بالفعل منطق قراءة `reviews.rating` و`reviews.rating_count`، لكن حقول لوحة الإدارة الجديدة موجودة تحت namespace `pandax`. لتكون لوحة الإدارة هي مصدر التقييم والشارات وطرق الدفع، عدّل القالب ليقرأ:
- `product.metafields.pandax.rating`
- `product.metafields.pandax.rating_count`
- `product.metafields.pandax.badge`
- `product.metafields.pandax.payment_modes`
- `product.metafields.pandax.offer_end`

يوجد ملف `theme-patch/product-card.liquid` كبديل جاهز لبطاقة المنتج.

## نشر اللوحة
يمكن نشرها على أي استضافة Node مثل Render أو Railway أو VPS. أضف نفس متغيرات البيئة في إعدادات الاستضافة، ولا تضع Client Secret في JavaScript أو GitHub.

## الأمان
- غيّر `ADMIN_PASSWORD` و`SESSION_SECRET` قبل النشر.
- لا ترفع `.env` إلى GitHub.
- استخدم HTTPS في الإنتاج.
- اطلب أقل صلاحيات Shopify لازمة فقط.
